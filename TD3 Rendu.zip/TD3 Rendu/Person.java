package models ;

//import javax.persistence.*;
import play.data.validation.*;
import play.data.validation.Constraints.*;
//import com.avaje.ebean.Model;

public class Person{
    
    @Required
    @Pattern(
        value = "^[A-Z][a-z]{2,}",message ="The firstname starts with uppercase and min caracters")
    public String firstname ;
    
    @Min(value=18, message="Age should be >= 18 and <= 25")
    @Max(value=25)
    public int age ;
    
    public Person(String firstname, int age){
        this.firstname = firstname;
        this.age = age;
    }
    
    public Person(){}
    
    public String getFirstname(){
        return this.firstname;
    }
    
    public int getAge(){
        return this.age;
    }
    
    public void setFirstname(String f){
        this.firstname = f;
    }
    
    public void setAge(int a){
        this.age=a;
    }
}

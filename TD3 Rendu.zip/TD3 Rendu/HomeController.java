package controllers;

import play.mvc.*;

import java.util.List ;
import play.data.*;
import javax.inject.Inject;
import views.html.*;
import models.Person ;
import play.i18n.MessagesApi;

public class HomeController extends Controller {

    public Result index() {
        return ok(views.html.index.render());
    }

    public Result helloworld() {
        return ok(views.html.helloworld.render("Lilou"));
    }
    
    public Result helloworld(String fname) {
        return ok(views.html.helloworld.render(fname));
    }
    
    @Inject FormFactory formFactory;
    Form < Person > personForm;
    MessagesApi messagesApi;
    
    @Inject
    public HomeController(FormFactory formFactory, MessagesApi messagesApi){
        this.personForm = formFactory.form(Person.class);
        this.messagesApi = messagesApi;
    }
    
    public Result sayhelloform(Http.Request request){
        return ok(views.html.sayhelloform.render(personForm,request,messagesApi.preferred(request)));
    }
    
    public Result helloworldform (Http.Request request) {
      Form<Person> pForm = personForm.bindFromRequest(request);
      if(pForm.hasErrors()) {
           return badRequest(sayhelloform.render(pForm,request,messagesApi.preferred(request)));
        }else{
            Person a = pForm.get();
            return ok(helloworldform.render(a)) ;
        }
    }
    
}












